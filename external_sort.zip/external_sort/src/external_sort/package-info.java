/**
 * Provides classes for external sort.
 */
package external_sort;